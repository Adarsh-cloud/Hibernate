package com.cg;

import javax.persistence.Entity;

@Entity
public class TemporaryEmployee extends Employe {
	private int dailyWage;

	public int getDailyWage() {
		return dailyWage;
	}

	public void setDailyWage(int dailyWage) {
		this.dailyWage = dailyWage;
	}

	
}
