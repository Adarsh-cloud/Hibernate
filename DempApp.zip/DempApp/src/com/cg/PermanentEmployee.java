package com.cg;

import javax.persistence.Entity;

@Entity
public class PermanentEmployee extends Employe{
	private double annualSalary;

	public double getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}
	
	
}
