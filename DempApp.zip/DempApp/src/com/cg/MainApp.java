package com.cg;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class MainApp {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		//Inserting one row in table
		/*Employee emp=new Employee(103,"John","Male",28,67000);
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		System.out.println("Data saved");*/
		/*em.getTransaction().begin();
		Employee emp=em.find(Employee.class,101);
		//Employee e1=em.find(Employee.class,103);
		System.out.println(emp);
		em.remove(emp);
		emp.setSalary(77000);
		em.getTransaction().commit();
		System.out.println(emp);*/
		
		/*Employee emp=new Employee();
		emp.setName("Mark");
		emp.setGender("Male");
		emp.setAge(24);
		emp.setSalary(45000);
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		em.close();
		factory.close();*/
//		Scanner scan=new Scanner(System.in);
		/*System.out.println("Enter gender");
		String gender=scan.nextLine();*/
//		TypedQuery<Employee> query=em.createQuery("from Employee",Employee.class);
		/*List<Employee> employees=query.getResultList();
		for(Employee employee:employees)
		{
			System.out.println(employee);
		}*/
//		TypedQuery<Employee> query=em.createQuery("from Employee where gender=:gen",Employee.class);
//		query.setParameter("gen",gender);
		/*System.out.println("Enter Employee Id");
		int id=scan.nextInt();
		TypedQuery<Employee> query=em.createQuery("from Employee where id=:eno",Employee.class);
		query.setParameter("eno",id);
		Employee emp=query.getSingleResult();
		System.out.println(emp);
		*/
		/*Query query=em.createQuery("delete from Employee where id=:id");
		query.setParameter("id",id);
		em.getTransaction().begin();
		int result=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+ " rows deleted");*/
		
		/*System.out.println("Enter gender");
		String gender=scan.nextLine();
		System.out.println("Enter salary");
		float sal=scan.nextFloat();
		System.out.println("Enter age");
		int ageNum=scan.nextInt();
		Query query=em.createQuery("update Employee set salary=salary+?,age=age+? where gender=?");
		query.setParameter(1,sal);
		query.setParameter(2,ageNum);
		query.setParameter(3,gender);
		Query query=em.createQuery("update Employee set salary=salary+:s,age=age+:a where gender=:g");
		query.setParameter("s",sal);
		query.setParameter("a",ageNum);
		query.setParameter("g",gender);
		em.getTransaction().begin();
		int result=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+ " row(s) updated");*/
		
		/*TypedQuery<Employee> query=em.createNamedQuery("getAllEmployees",Employee.class);
		List<Employee> employees=query.getResultList();
		for(Employee employee:employees)
		{
			System.out.println(employee);
		}
		query=em.createNamedQuery("getEmployeeByGender",Employee.class);
		query.setParameter("gen","Female");
		List<Employee> emp=query.getResultList();
		for(Employee empl:emp)
		{
			System.out.println(empl);
		}*/
		
		em.close();
		factory.close();
		
	}
}