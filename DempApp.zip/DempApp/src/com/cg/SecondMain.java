package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SecondMain {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		/*Faculty fac=new Faculty();
		fac.setName("Varsha");
		Technology tech1=new Technology();
		tech1.setTechnologyName("Java");
		Technology tech2=new Technology();
		tech2.setTechnologyName("BDD");
		fac.getTechnologies().add(tech1);
		fac.getTechnologies().add(tech2);
		tech1.getFaculty().add(fac);
		tech2.getFaculty().add(fac);
		em.getTransaction().begin();
		em.persist(fac);
		em.getTransaction().commit();*/
		/*Faculty fac=em.find(Faculty.class,1);
		System.out.println(fac);
		em.close();
		for (Technology tech :fac.getTechnologies()) {
			System.out.println(tech);
			
		}*/
		Employe employ=new Employe();
		employ.setName("Tanmay");
		TemporaryEmployee temp=new TemporaryEmployee();
		temp.setName("Shilpa");
		temp.setDailyWage(500);
		PermanentEmployee pemp=new PermanentEmployee();
		pemp.setName("Shivani");
		pemp.setAnnualSalary(56000);
		em.getTransaction().begin();
		em.persist(employ);
		em.persist(temp);
		em.persist(pemp);
		em.getTransaction().commit();
		System.out.println("Done");
		em.close();
		factory.close();
	}

}
