package com.assig;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Author author1=new Author(101,"William","Jordan","Shakespeare",38278912);
		Author author2=new Author(102,"Arthur","Conan","Doyle",2178938);
		em.getTransaction().begin();
		em.persist(author1); // 1st row inserted
		em.persist(author2); // 2nd row inserted
		Author author=em.find(Author.class,101);
		author.setMiddleName(""); //Middle name updated
		em.remove(author2);
		em.getTransaction().commit();
	}

}
